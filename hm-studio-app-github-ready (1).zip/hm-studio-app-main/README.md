# HM Studio Android App

این مخزن نسخه Android پروژه HM Studio را با GitHub Actions به APK قابل نصب تبدیل می‌کند.

## ساخت APK

1. فایل `android_source_for_github.zip` را در ریشه مخزن نگه دارید.
2. تغییرات را روی شاخه `main` یا `master` push کنید، یا از GitHub وارد **Actions → Build Android APK → Run workflow** شوید.
3. پس از موفقیت Build، از بخش **Artifacts** فایل `HM-Studio-App-APK` را دریافت کنید.
4. فایل `app-debug.apk` را روی گوشی Android نصب کنید.

### نکته
این Workflow عمداً از Gradle 8.11.1 و JDK 17 استفاده می‌کند و به `gradle-wrapper.jar` وابسته نیست.
