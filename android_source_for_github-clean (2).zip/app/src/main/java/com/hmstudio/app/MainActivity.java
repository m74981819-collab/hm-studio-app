package com.hmstudio.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

/**
 * HM Studio — pristine WebView shell.
 *
 * Design goals:
 *  - Rock solid: no crashes, no leaks, single stable WebView instance,
 *    configuration changes handled without recreation (no jitter/flash).
 *  - Zero animations: window animations disabled (see styles.xml), all CSS
 *    transitions/animations and smooth-scroll neutralized at page level,
 *    overscroll glow disabled.
 *  - Safe areas: system-bar insets applied as stable padding (top for the
 *    status bar, bottom for gesture nav), never clipping content.
 *  - Bottom navigation: native dark bottom bar with gold accent that jumps
 *    instantly (behavior:'auto', no smooth scrolling) to page sections.
 */
public class MainActivity extends Activity {

    private static final String START_URL = "file:///android_asset/index.html";
    private static final int COLOR_BG = 0xFF06111F;   // deep navy
    private static final int COLOR_ACCENT = 0xFFF6C453; // gold

    private WebView webView;
    private LinearLayout bottomBar;

    /** Anchors mirrored from index.html sections; labels are Persian (RTL UI). */
    private static final String[] SECTION_IDS =
            {"home", "services", "portfolio", "testimonials", "contact"};
    private static final String[] SECTION_LABELS =
            {"خانه", "خدمات", "نمونه‌کار", "نظرات", "تماس"};

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Solid, animation-free window.
        getWindow().setBackgroundColor(COLOR_BG);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(COLOR_BG);

        webView = new WebView(this);
        webView.setBackgroundColor(COLOR_BG);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER); // no glow/bounce jitter
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        configureWebSettings(webView.getSettings());
        configureClients();

        FrameLayout.LayoutParams webLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT);
        root.addView(webView, webLp);

        bottomBar = buildBottomBar();
        LinearLayout.LayoutParams barLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(58));
        FrameLayout.LayoutParams barFrameLp = new FrameLayout.LayoutParams(barLp);
        barFrameLp.gravity = Gravity.BOTTOM;
        root.addView(bottomBar, barFrameLp);

        setContentView(root);
        applySafeAreaInsets(root);
        bottomBar.getLayoutParams().height += getNavBarHeightFallback();

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState); // no reload flash on recreation
        } else {
            webView.loadUrl(START_URL);
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebSettings(WebSettings s) {
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setNeedInitialFocus(false);
        s.setTextZoom(100); // ignore system font-scale jumps: stable layout
    }

    private void configureClients() {
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return openExternal(request.getUrl().toString());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return openExternal(url);
            }

            private boolean openExternal(String url) {
                if (url == null || url.startsWith("file://")) return false;
                try {
                    startActivity(new android.content.Intent(
                            android.content.Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) { }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                // Kill every animation/transition/smooth-scroll inside the page:
                // zero jitter, instant state changes, static canvases.
                view.evaluateJavascript(
                    "(function(){" +
                    "var st=document.createElement('style');st.id='native-no-anim';" +
                    "st.textContent='*,*::before,*::after{animation:none!important;" +
                    "transition:none!important;animation-duration:0s!important;" +
                    "transition-duration:0s!important;scroll-behavior:auto!important;" +
                    "backdrop-filter:none!important;-webkit-backdrop-filter:none!important;}" +
                    "html{scroll-behavior:auto!important;overscroll-behavior:none}';" +
                    "document.head.appendChild(st);" +
                    "['redParticles','mouseParticles'].forEach(function(id){" +
                    "var c=document.getElementById(id);if(c){c.style.display='none'}});" +
                    "var sp=document.getElementById('mouseSpotlight');" +
                    "if(sp){sp.style.display='none'}" +
                    "})();", null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
    }

    private LinearLayout buildBottomBar() {
        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setBackgroundColor(COLOR_BG);
        bottomBar.setElevation(dp(8));
        for (int i = 0; i < SECTION_IDS.length; i++) {
            final String section = SECTION_IDS[i];
            Button b = new Button(this, null, 0); // borderless: flat, no ripple animation
            b.setText(SECTION_LABELS[i]);
            b.setAllCaps(false);
            b.setTextSize(12f);
            b.setTextColor(Color.WHITE);
            b.setBackgroundColor(Color.TRANSPARENT);
            b.setTypeface(null, android.graphics.Typeface.BOLD);
            b.setGravity(Gravity.CENTER);
            b.setOnClickListener(v -> jumpTo(section));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.MATCH_PARENT, 1f);
            bottomBar.addView(b, lp);
        }
        return bottomBar;
    }

    /** Instant jump — behavior:'auto' so there is zero smooth-scroll jitter. */
    private void jumpTo(String sectionId) {
        if (webView == null) return;
        String js = "(function(){var e=document.getElementById('" + sectionId + "');" +
                "if(e){e.scrollIntoView({behavior:'auto',block:'start'})}" +
                "else{window.scrollTo(0,0)}})();";
        webView.evaluateJavascript(js, null);
    }

    /** Stable safe-area padding: status bar above, gesture nav below the bottom bar. */
    private void applySafeAreaInsets(final FrameLayout root) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets sys = insets.getInsets(
                        WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                webView.setPadding(0, sys.top, 0, 0);
                bottomBar.setPadding(0, 0, 0, sys.bottom);
                bottomBar.getLayoutParams().height = dp(58) + sys.bottom;
                bottomBar.requestLayout();
                return WindowInsets.CONSUMED;
            });
        }
    }

    private int getNavBarHeightFallback() {
        // Below API 30 navigation bars are opaque colored; bottom bar sits above them.
        return 0;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.onPause();
            webView.removeAllViews();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
