const RECIPIENT_EMAIL = 'm74981819@gmail.com';

function doPost(e) {
  try {
    const raw = e && e.postData && e.postData.contents ? e.postData.contents : '{}';
    const data = JSON.parse(raw);

    const subject = 'سفارش جدید پروژه - HM Studio';
    const body = [
      'سفارش جدید پروژه',
      '------------------------',
      'نام: ' + (data.firstName || ''),
      'نام خانوادگی: ' + (data.lastName || ''),
      'کشور: ' + (data.country || ''),
      'ایمیل مشتری: ' + (data.email || ''),
      'شماره تماس: ' + (data.phone || ''),
      'نوع پروژه: ' + (data.projectType || ''),
      'بودجه: ' + (data.budget || ''),
      'موقعیت: ' + (data.location || ''),
      '',
      'توضیحات پروژه:',
      data.description || '',
      '',
      'زمان ثبت: ' + (data.createdAt || ''),
      'زبان فرم: ' + (data.language || '')
    ].join('\n');

    MailApp.sendEmail({
      to: RECIPIENT_EMAIL,
      subject: subject,
      body: body,
      replyTo: data.email || RECIPIENT_EMAIL,
      name: 'HM Studio Orders'
    });

    return ContentService
      .createTextOutput(JSON.stringify({ok:true}))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ok:false,error:String(err)}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

function doGet() {
  return ContentService
    .createTextOutput(JSON.stringify({ok:true,service:'HM Studio order endpoint'}))
    .setMimeType(ContentService.MimeType.JSON);
}
