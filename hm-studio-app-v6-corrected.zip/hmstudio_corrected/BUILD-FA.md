HM Studio V5

تغییرات اصلی:
- Workflow ساخت APK دیگر به gradle-wrapper.jar وابسته نیست و Gradle 8.11.1 را در GitHub Actions نصب می‌کند.
- ارسال سفارش فرم بدون نیاز به endpoint اجباری از طریق دکمه‌های واتساپ و پیامک آماده می‌شود.
- در صورت تنظیم Google Apps Script، فرم هم‌زمان می‌تواند اطلاعات را به backend ارسال کند.
- باز کردن mailto/sms در MainActivity اصلاح شده است.
- بستن modal و لایه‌های باز با دکمه بستن، Escape و دکمه Back اندروید حفظ شده است.
