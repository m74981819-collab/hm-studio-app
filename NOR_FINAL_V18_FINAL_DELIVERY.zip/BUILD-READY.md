HMStudio — Build Ready
=======================

ساختار:
HMStudio/
  assets/ ...                # وب‌سایت اصلی
  backend/
  database/
  docs/
  locales/
  tests/
  404.html
  admin.html
  app.js
  index.html
  manifest.webmanifest
  portfolio.html
  README.md
  START-HERE.txt
  styles.css
  sw.js
  VERSION.txt
  android-app/               # پروژه Android Studio

ساخت APK:
1) Android Studio را نصب کنید (JDK 17).
2) پوشه HMStudio/android-app را Open کنید.
3) Gradle Sync را انجام دهید.
4) Build > Build APK(s) را بزنید.
5) APK دیباگ در app/build/outputs/apk/debug/ ساخته می‌شود.

برای نسخه انتشار:
Build > Generate Signed Bundle / APK > APK
و یک keystore شخصی بسازید/انتخاب کنید.

نکته:
gradle-wrapper.properties اضافه شده و پروژه برای Gradle 8.11.1 + Android Gradle Plugin 8.7.3 تنظیم شده است.
در این بسته wrapper JAR قرار داده نشده؛ Android Studio در اولین Sync آن را مدیریت/دریافت می‌کند.

نسخه وب و Android هر دو از همان طراحی و افکت‌های قرمز استفاده می‌کنند.
