/* NOR — reliable PWA installation controller */
(() => {
  const buttons = [...document.querySelectorAll('#installBtn, #menuInstallBtn, [data-command="install"]')];
  if (!buttons.length) return;

  let deferredPrompt = null;
  let installInProgress = false;
  const isStandalone = () => window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;

  const setState = (ready) => {
    buttons.forEach((b) => {
      b.classList.toggle('install-ready', ready);
      b.classList.toggle('install-waiting', !ready);
      b.setAttribute('aria-disabled', ready ? 'false' : 'true');
    });
  };

  const hideInstalled = () => buttons.forEach((b) => { b.hidden = true; });

  if (isStandalone()) { hideInstalled(); return; }
  setState(false);

  const capture = (event) => {
    event.preventDefault();
    deferredPrompt = event;
    setState(true);
  };
  window.addEventListener('beforeinstallprompt', capture);

  window.addEventListener('appinstalled', () => {
    deferredPrompt = null;
    installInProgress = false;
    hideInstalled();
  });

  async function install() {
    if (installInProgress || isStandalone()) return;
    installInProgress = true;
    try {
      // Give the browser a chance to finish service-worker readiness.
      if ('serviceWorker' in navigator) {
        try { await Promise.race([navigator.serviceWorker.ready, new Promise(r => setTimeout(r, 1200))]); } catch (_) {}
      }

      // beforeinstallprompt can arrive a moment after the click on a first visit.
      const until = Date.now() + 3500;
      while (!deferredPrompt && Date.now() < until) {
        await new Promise(r => setTimeout(r, 100));
      }
      const promptEvent = deferredPrompt;
      if (!promptEvent) return;

      deferredPrompt = null;
      setState(false);
      promptEvent.prompt();
      await promptEvent.userChoice;
    } finally {
      installInProgress = false;
      if (!isStandalone() && !deferredPrompt) setState(false);
    }
  }

  window.NORInstallApp = install;

  buttons.forEach((button) => {
    button.addEventListener('click', (event) => {
      event.preventDefault();
      event.stopPropagation();
      install();
    }, false);
  });
})();
