/* Live count-up: 0 -> requested values, and skill meters 0 -> target. */
(() => {
  function ease(t){ return 1-Math.pow(1-t,4); }
  function animate(el, ms=1500){
    const target=Number(el.dataset.target||0), prefix=el.dataset.prefix||'', suffix=el.dataset.suffix||'';
    const start=performance.now();
    function tick(now){
      const t=Math.min(1,(now-start)/ms), v=Math.round(target*ease(t));
      el.textContent=prefix+v.toLocaleString('en-US')+suffix;
      if(t<1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }
  document.addEventListener('DOMContentLoaded',()=>{
    const counters=[...document.querySelectorAll('.count-up')];
    const meters=[...document.querySelectorAll('.meter i[data-target-width]')];
    const run=()=>{ counters.forEach((e,i)=>setTimeout(()=>animate(e,1700+i*120),i*120)); meters.forEach((e,i)=>setTimeout(()=>{
      const target=e.dataset.targetWidth||0, start=performance.now();
      const tick=now=>{const t=Math.min(1,(now-start)/1500);e.style.width=(Number(target)*ease(t)).toFixed(1)+'%';if(t<1)requestAnimationFrame(tick)};requestAnimationFrame(tick);
    },i*90)); };
    if('IntersectionObserver' in window){const obs=new IntersectionObserver(entries=>{if(entries.some(e=>e.isIntersecting)){run();obs.disconnect()}},{threshold:.25});const sec=document.querySelector('.stats-section');if(sec)obs.observe(sec);else run();}
    else run();
  });
})();



let statsAnimated = false;
function initSkillCounters() {
    if (statsAnimated) return;
    statsAnimated = true;
    const meters = document.querySelectorAll('.meter i');
    meters.forEach((meter, index) => {
        const targetVal = parseFloat(meter.getAttribute('data-target-width')) || 0;
        const parentMeter = meter.closest('.meter');
        const labelB = parentMeter && parentMeter.previousElementSibling ? parentMeter.previousElementSibling.querySelector('b') : null;
        let startTimestamp = null;
        function step(timestamp) {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / 1500, 1);
            meter.style.width = (progress * targetVal) + '%';
            if (labelB) labelB.textContent = Math.floor(progress * targetVal) + '%';
            if (progress < 1) {
                requestAnimationFrame(step);
            } else if (labelB) {
                labelB.textContent = targetVal + '%';
            }
        }
        setTimeout(() => { requestAnimationFrame(step); }, index * 90);
    });
}
const statsElem = document.querySelector('.section.stats') || document.querySelector('.skills-section');
if (statsElem) {
    const observer = new IntersectionObserver((entries) => {
        if (entries[0].isIntersecting) {
            initSkillCounters();
            observer.disconnect();
        }
    }, { threshold: 0.25 });
    observer.observe(statsElem);
}






















