const CACHE = 'nor-v18';
self.addEventListener('install', (event) => self.skipWaiting());
self.addEventListener('message', (event) => {
  if (event.data?.type === 'SKIP_WAITING') self.skipWaiting();
});
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  const url = new URL(event.request.url);
  if (url.origin !== location.origin) return;
  if (url.pathname.endsWith('/sw.js') || url.pathname.endsWith('/sw-v16.js') || url.pathname.endsWith('/sw-v17.js')) return;
  if (event.request.mode === 'navigate') {
    event.respondWith(fetch(event.request).then(response => {
      if (response.ok) caches.open(CACHE).then(c => c.put('./index.html', response.clone())).catch(() => {});
      return response;
    }).catch(() => caches.match('./index.html')));
    return;
  }
  event.respondWith(fetch(event.request).then(response => {
    if (response.ok && response.type === 'basic') caches.open(CACHE).then(c => c.put(event.request, response.clone())).catch(() => {});
    return response;
  }).catch(() => caches.match(event.request)));
});
