# نصب اپلیکیشن

ویندوز: `START-LOCALHOST.bat` را اجرا کنید؛ سایت با `http://localhost:8765/` باز می‌شود؛ سپس «نصب اپلیکیشن» را بزنید.

گوشی: برای PWA باید سایت روی HTTPS باشد.

Android: پوشه `android-app` را در Android Studio باز کنید و APK بسازید.

اجرای مستقیم `file://` برای نصب PWA پشتیبانی نمی‌شود.
