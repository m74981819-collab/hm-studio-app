# V12
- Applied confirmed phone/WhatsApp number.
- Prepared final integration build.

# V11
- Hardened native PWA install prompt handling.
- Fresh service worker filename/cache to avoid stale PWA workers.
- Fixed direct phone/WhatsApp/Telegram/email click navigation.
- Fixed music control and starts ambient music on first user gesture.

# Changelog

## Final
- Testimonials: 10 rotating slides, controls/dots inside card.
- Stats: +500 / +10 / 24/7 / +3.
- Achievements section retained.
- Interactive red particles respond to mouse and touch.
- PWA install support for Android and desktop browsers.
