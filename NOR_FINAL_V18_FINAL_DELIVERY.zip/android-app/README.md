# HM Studio — Android App

This is a native Android WebView wrapper around the supplied HM Studio site.

## Build
1. Open this folder in Android Studio (Ladybug or newer recommended).
2. Let Gradle sync and download the Android Gradle Plugin/dependencies.
3. Run on a device/emulator, or choose **Build > Build APK(s)**.
4. For Play Store, choose **Build > Generate Signed App Bundle / APK** and select AAB.

Application ID: `com.hmstudio.app`
Version: `1.0.0`

The website is bundled locally in `app/src/main/assets`, so the core UI loads without hosting. External links and Google Fonts require network access.
