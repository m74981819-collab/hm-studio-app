/* NOR — real PWA installation controller.
   Android/Chrome/Edge: uses the browser's real beforeinstallprompt.
   iOS/iPadOS: uses the browser's Add to Home Screen flow (Apple does not expose a JS install prompt).
*/
(() => {
  'use strict';
  const buttons = [...document.querySelectorAll('#installBtn, #menuInstallBtn, [data-command="install"]')];
  if (!buttons.length) return;

  let deferredPrompt = null;
  let promptSeen = false;
  const isStandalone = () => window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

  function setReady(ready) {
    buttons.forEach(btn => {
      btn.classList.toggle('install-ready', !!ready);
      btn.setAttribute('aria-disabled', ready ? 'false' : 'true');
      btn.dataset.installReady = ready ? '1' : '0';
    });
  }

  function setInstalled() {
    buttons.forEach(btn => {
      btn.hidden = true;
      btn.classList.remove('install-ready');
    });
  }

  if (isStandalone()) { setInstalled(); return; }
  setReady(false);

  // Capture the browser's real install event before any other app handler can interfere.
  window.addEventListener('beforeinstallprompt', event => {
    event.preventDefault();
    deferredPrompt = event;
    promptSeen = true;
    setReady(true);
  }, { capture: true });

  window.addEventListener('appinstalled', () => {
    deferredPrompt = null;
    setInstalled();
  });

  async function install() {
    if (deferredPrompt) {
      const prompt = deferredPrompt;
      deferredPrompt = null;
      setReady(false);
      try {
        prompt.prompt();
        const choice = await prompt.userChoice;
        if (choice && choice.outcome === 'accepted') setInstalled();
      } catch (_) {
        // Browser cancelled or rejected the prompt; wait for the next event.
      }
      return true;
    }

    // There is no standards-based way to force an install dialog when the browser
    // has not supplied beforeinstallprompt. Never fake an installation.
    if (isIOS) {
      showInlineHint('در آیفون/آیپد: Share را بزنید و Add to Home Screen را انتخاب کنید.');
    } else {
      showInlineHint('مرورگر هنوز گزینه نصب را ارائه نکرده است؛ صفحه را یک‌بار تازه‌سازی کنید و دوباره بزنید.');
    }
    return false;
  }

  function showInlineHint(text) {
    let el = document.getElementById('norInstallHint');
    if (!el) {
      el = document.createElement('div');
      el.id = 'norInstallHint';
      el.setAttribute('role', 'status');
      el.className = 'nor-install-hint';
      const anchor = document.getElementById('installBtn') || buttons[0];
      anchor?.parentNode?.appendChild(el);
    }
    el.textContent = text;
    el.hidden = false;
    clearTimeout(el._hideTimer);
    el._hideTimer = setTimeout(() => { el.hidden = true; }, 7000);
  }

  window.NORInstallApp = install;
  window.NORInstallReady = () => !!deferredPrompt;

  buttons.forEach(btn => btn.addEventListener('click', event => {
    event.preventDefault();
    event.stopPropagation();
    install();
  }, { capture: true }));

  // Give Chrome/Edge a short window to deliver beforeinstallprompt.
  setTimeout(() => {
    if (!promptSeen && !isStandalone()) setReady(false);
  }, 8000);
})();
