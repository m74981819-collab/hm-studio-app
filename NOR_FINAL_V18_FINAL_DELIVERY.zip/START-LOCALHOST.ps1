$ErrorActionPreference="Stop"
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$port=8765;$url="http://localhost:$port/"
$l=New-Object System.Net.HttpListener;$l.Prefixes.Add($url);$l.Start();Start-Process $url
Write-Host "HM Studio running at $url"
while($l.IsListening){$c=$l.GetContext();try{$p=[Uri]::UnescapeDataString($c.Request.Url.AbsolutePath.TrimStart("/"));if(!$p){$p="index.html"};$f=Join-Path $root $p;if(Test-Path $f -PathType Leaf){$b=[IO.File]::ReadAllBytes($f);$e=[IO.Path]::GetExtension($f).ToLower();$m=@{".html"="text/html; charset=utf-8";".css"="text/css; charset=utf-8";".js"="application/javascript; charset=utf-8";".webmanifest"="application/manifest+json";".svg"="image/svg+xml";".png"="image/png";".jpg"="image/jpeg";".jpeg"="image/jpeg";".webp"="image/webp";".mp3"="audio/mpeg";".mp4"="video/mp4"};$c.Response.ContentType=if($m.ContainsKey($e)){$m[$e]}else{"application/octet-stream"};$c.Response.StatusCode=200;$c.Response.OutputStream.Write($b,0,$b.Length)}else{$c.Response.StatusCode=404}}finally{$c.Response.Close()}}
