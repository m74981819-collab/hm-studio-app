(()=>{const C=window.SITE_CONFIG||{};
const waLink=document.querySelector('.contact-links a[href^="https://wa.me"]'); if(waLink&&C.social?.whatsapp) waLink.href=C.social.whatsapp; const tgLink=document.querySelector('.contact-links a[href^="https://t.me"]'); if(tgLink&&C.social?.telegram) tgLink.href=C.social.telegram; const emailLink=document.querySelector('.contact-links a[href^="#emailFallback"]'); if(emailLink&&C.email){emailLink.href='mailto:'+C.email;emailLink.removeAttribute('aria-label');} else if(emailLink){emailLink.addEventListener('click',e=>{e.preventDefault();document.querySelector('#emailFallback')?.scrollIntoView({behavior:'smooth',block:'center'});});}const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const translations={fa:{brand:'حسین منصوری',brandRole:'طراح و توسعه‌دهنده دیجیتال',navHome:'خانه',navServices:'خدمات',navPortfolio:'نمونه‌کار',navTestimonials:'نظرات',navContact:'تماس',eyebrow:'استودیو شخصی طراحی و توسعه',heroTitle:'طراح سایت و وب‌اپلیکیشن حرفه‌ای',heroName:'حسین منصوری',heroText:'وب‌سایت‌ها و محصولات دیجیتال سریع، زیبا و قابل توسعه می‌سازم؛ از ایده و UI/UX تا توسعه، PWA، هوش مصنوعی، اتوماسیون، SEO، امنیت و بهینه‌سازی عملکرد.',startProject:'شروع پروژه',viewWork:'مشاهده نمونه‌کارها',available:'آماده همکاری',liveTimeLabel:'ساعت زنده',liveDateLabel:'تاریخ زنده',calendarLabel:'تقویم زنده',servicesKicker:'توانایی‌ها',servicesTitle:'یک مسیر کامل از ایده تا محصول',servicesText:'طراحی، توسعه و بهینه‌سازی در یک تجربه یکپارچه.',s1:'طراحی UI / UX',s1p:'رابط‌های مدرن، واکنش‌گرا و تجربه کاربری هدفمند.',s2:'Web App و PWA',s2p:'اپلیکیشن‌های وب سریع با نصب‌پذیری، کش و قابلیت Offline.',s3:'هوش مصنوعی و اتوماسیون',s3p:'اتصال AI به فرایندهای واقعی کسب‌وکار برای کاهش کار تکراری.',s4:'SEO، امنیت و Performance',s4p:'ساختار فنی بهتر، بارگذاری سریع، دسترسی‌پذیری و ملاحظات امنیتی.',statProjects:'پروژه / ظرفیت نمونه',statYears:'سال تجربه هدف‌گذاری‌شده',statPerformance:'تمرکز بر Performance',statSupport:'پشتیبانی و توسعه',portfolioTitle:'نمونه‌کارهای تعاملی',portfolioText:'سناریوهای نمایشی و یک فیلم معرفی حرفه‌ای برای تجربه مستقیم محصول.',pwaDesc:'فروشگاه وب نصب‌پذیر با حالت آفلاین و رابط موبایل‌محور.',aiDesc:'داشبورد هوش مصنوعی با جریان گفتگو، KPI و اتوماسیون.',globalDesc:'لندینگ بین‌المللی چندزبانه با تمرکز بر تبدیل و سرعت.',brandFilmTitle:'فیلم معرفی حرفه‌ای حسین منصوری',brandFilmText:'ویدیوی سینمایی کوتاه برای معرفی هویت حرفه‌ای، طراحی محصول و خدمات دیجیتال.',emailNote:'ایمیل مستقیم پس از ثبت ایمیل شما در config.js فعال می‌شود.',aboutKicker:'معرفی حرفه‌ای',aboutTitle:'طراحی برای امروز؛ معماری برای فردا.',aboutText:'من حسین منصوری هستم؛ طراح و توسعه‌دهنده محصولات دیجیتال. هدف من فقط تحویل یک صفحه زیبا نیست؛ محصول باید سریع، قابل استفاده، قابل نگهداری، امن و آماده توسعه آینده باشد.',certTitle:'مدارک و دستاوردها',certText:'محل آماده برای افزودن مدارک واقعی، لینک اعتبارسنجی و دستاوردها.',cert1:'گواهی طراحی محصول',cert2:'توسعه وب پیشرفته',cert3:'AI & Automation',testKicker:'بازخورد',testTitle:'نظر مشتریان',contactTitle:'پروژه بعدی شما می‌تواند از همین‌جا شروع شود.',contactText:'اطلاعات پروژه را بفرستید؛ فرم در لحظه اعتبارسنجی می‌شود و امکان ورود صوتی نیز دارد.',firstName:'نام',lastName:'نام خانوادگی',country:'کشور',email:'ایمیل',phone:'شماره تماس',projectType:'نوع پروژه',budget:'بودجه',location:'موقعیت',getLocation:'دریافت موقعیت با اجازه شما',description:'توضیحات پروژه',listening:'در حال گوش دادن… فارسی / English / العربية',sendProject:'ارسال درخواست پروژه',mapTitle:'موقعیت و دسترسی',mapText:'تهران و کرج / مهرشهر؛ موقعیت دقیق با اجازه کاربر قابل اشتراک‌گذاری است.',footerRole:'طراح سایت و وب‌اپلیکیشن حرفه‌ای',textSizeLabel:'اندازه متن',textSmall:'ریز',textMedium:'متوسط',textLarge:'بزرگ',textXLarge:'خیلی بزرگ',installApp:'نصب اپلیکیشن',quickInstall:'نصب اپلیکیشن',updateApp:'بروزرسانی اپلیکیشن',quickUpdate:'بروزرسانی اپلیکیشن'},en:{brand:'Hossein Mansouri',brandRole:'Digital Designer & Developer',navHome:'Home',navServices:'Services',navPortfolio:'Portfolio',navTestimonials:'Testimonials',navContact:'Contact',eyebrow:'Personal design & development studio',heroTitle:'Professional Web & Web App Designer',heroName:'Hossein Mansouri',heroText:'I design and build fast, beautiful, scalable digital products—from UI/UX and development to PWA, AI, automation, SEO, security and performance.',startProject:'Start a project',viewWork:'View work',available:'Available for work',liveTimeLabel:'LIVE TIME',liveDateLabel:'LIVE DATE',calendarLabel:'LIVE CALENDAR',servicesKicker:'CAPABILITIES',servicesTitle:'One path from idea to product',servicesText:'Design, engineering and optimization in one coherent experience.',s1:'UI / UX Design',s1p:'Modern responsive interfaces and purposeful user experiences.',s2:'Web Apps & PWA',s2p:'Installable web apps with caching and offline capability.',s3:'AI & Automation',s3p:'Connect AI to real business workflows and remove repetitive work.',s4:'SEO, Security & Performance',s4p:'Better technical structure, speed, accessibility and security-minded delivery.',statProjects:'projects / sample capacity',statYears:'years target experience',statPerformance:'performance focus',statSupport:'support & growth',portfolioTitle:'Interactive portfolio',portfolioText:'Three demo scenarios you can experience directly.',pwaDesc:'Installable commerce PWA with offline mode and mobile-first UI.',aiDesc:'AI dashboard with conversation flow, KPIs and automation.',globalDesc:'Multilingual global landing page focused on conversion and speed.',brandFilmTitle:'Hossein Mansouri Professional Brand Film',brandFilmText:'A short cinematic film introducing professional identity, product design and digital services.',emailNote:'Direct email activates after you add your email in config.js.',aboutKicker:'PROFESSIONAL PROFILE',aboutTitle:'Design for today. Architecture for tomorrow.',aboutText:'I am Hossein Mansouri, a digital product designer and developer. The goal is not just a beautiful page; the product should be fast, usable, maintainable, secure and ready to evolve.',certTitle:'Certificates & achievements',certText:'Ready area for real certificates, validation links and achievements.',cert1:'Product Design Certificate',cert2:'Advanced Web Development',cert3:'AI & Automation',testKicker:'FEEDBACK',testTitle:'Client testimonials',contactTitle:'Your next project can start here.',contactText:'Send your project details; the form validates live and also supports voice input.',firstName:'First name',lastName:'Last name',country:'Country',email:'Email',phone:'Phone',projectType:'Project type',budget:'Budget',location:'Location',getLocation:'Get location with permission',description:'Project description',listening:'Listening… فارسی / English / العربية',sendProject:'Send project request',mapTitle:'Locations & access',mapText:'Tehran and Karaj / Mehrshahr; precise location is shared only with permission.',footerRole:'Professional Web & Web App Designer',textSizeLabel:'Text size',textSmall:'Small',textMedium:'Medium',textLarge:'Large',textXLarge:'Very large',installApp:'Install app',quickInstall:'Install app',updateApp:'Update app',quickUpdate:'Update app'},ar:{brand:'حسين منصوري',brandRole:'مصمم ومطور رقمي',navHome:'الرئيسية',navServices:'الخدمات',navPortfolio:'الأعمال',navTestimonials:'آراء العملاء',navContact:'اتصل',eyebrow:'استوديو التصميم والتطوير الشخصي',heroTitle:'مصمم مواقع وتطبيقات ويب محترف',heroName:'حسين منصوري',heroText:'أصمم وأطور منتجات رقمية سريعة وجميلة وقابلة للتوسع، من UI/UX إلى PWA والذكاء الاصطناعي والأتمتة وSEO والأمان والأداء.',startProject:'ابدأ مشروعاً',viewWork:'مشاهدة الأعمال',available:'متاح للتعاون',liveTimeLabel:'الوقت المباشر',liveDateLabel:'التاريخ المباشر',calendarLabel:'التقويم المباشر',servicesKicker:'القدرات',servicesTitle:'مسار متكامل من الفكرة إلى المنتج',servicesText:'التصميم والتطوير والتحسين ضمن تجربة واحدة.',s1:'تصميم UI / UX',s1p:'واجهات حديثة متجاوبة وتجربة مستخدم هادفة.',s2:'Web App وPWA',s2p:'تطبيقات ويب قابلة للتثبيت مع التخزين المؤقت والعمل دون اتصال.',s3:'الذكاء الاصطناعي والأتمتة',s3p:'ربط الذكاء الاصطناعي بعمليات العمل وتقليل المهام المتكررة.',s4:'SEO والأمان والأداء',s4p:'بنية تقنية أفضل وسرعة وإمكانية وصول وتسليم يراعي الأمان.',statProjects:'مشاريع / سعة تجريبية',statYears:'سنوات خبرة مستهدفة',statPerformance:'تركيز على الأداء',statSupport:'الدعم والتطوير',portfolioTitle:'أعمال تفاعلية',portfolioText:'ثلاثة نماذج يمكنك تجربتها مباشرة.',pwaDesc:'متجر PWA قابل للتثبيت مع وضع عدم الاتصال وواجهة أولاً للهاتف.',aiDesc:'لوحة ذكاء اصطناعي مع محادثة ومؤشرات وأتمتة.',globalDesc:'صفحة عالمية متعددة اللغات تركز على التحويل والسرعة.',brandFilmTitle:'فيلم حسين منصوري الاحترافي',brandFilmText:'فيلم سينمائي قصير يقدم الهوية المهنية وتصميم المنتجات والخدمات الرقمية.',emailNote:'يتم تفعيل البريد المباشر بعد إضافة بريدك في config.js.',aboutKicker:'الملف المهني',aboutTitle:'تصميم لليوم؛ وهندسة للغد.',aboutText:'أنا حسين منصوري، مصمم ومطور للمنتجات الرقمية. الهدف ليس صفحة جميلة فقط؛ يجب أن يكون المنتج سريعاً وقابلاً للاستخدام والصيانة وآمناً وقابلاً للتوسع.',certTitle:'الشهادات والإنجازات',certText:'مساحة لإضافة الشهادات الحقيقية وروابط التحقق والإنجازات.',cert1:'شهادة تصميم المنتجات',cert2:'تطوير ويب متقدم',cert3:'الذكاء الاصطناعي والأتمتة',testKicker:'آراء',testTitle:'آراء العملاء',contactTitle:'يمكن أن يبدأ مشروعك القادم من هنا.',contactText:'أرسل تفاصيل المشروع؛ النموذج يتحقق فورياً ويدعم الإدخال الصوتي.',firstName:'الاسم',lastName:'اسم العائلة',country:'الدولة',email:'البريد الإلكتروني',phone:'رقم الهاتف',projectType:'نوع المشروع',budget:'الميزانية',location:'الموقع',getLocation:'الحصول على الموقع بإذنك',description:'وصف المشروع',listening:'جارٍ الاستماع… فارسی / English / العربية',sendProject:'إرسال طلب المشروع',mapTitle:'المواقع والوصول',mapText:'طهران وكرج / مهرشهر؛ تتم مشاركة الموقع الدقيق بإذن المستخدم فقط.',footerRole:'مصمم مواقع وتطبيقات ويب محترف',textSizeLabel:'حجم النص',textSmall:'صغير',textMedium:'متوسط',textLarge:'كبير',textXLarge:'كبير جدًا',installApp:'تثبيت التطبيق',quickInstall:'تثبيت التطبيق',updateApp:'تحديث التطبيق',quickUpdate:'تحديث التطبيق'}};


Object.assign(translations.fa,{test1:'«طراحی تمیز، سرعت خوب و دقت بالا در اجرای جزئیات؛ نتیجه دقیقاً نزدیک به چیزی بود که انتظار داشتیم.»',test1Title:'تجربه همکاری نمونه ۱',test1Role:'نمونه نمایشی',test2:'«فرایند همکاری منظم بود و از ایده اولیه تا اجرای نهایی، مسیر کاملاً قابل پیگیری پیش رفت.»',test2Title:'تجربه همکاری نمونه ۲',test2Role:'نمونه نمایشی',test3:'«رابط کاربری حرفه‌ای و واکنش‌گراست و روی موبایل هم تجربه بسیار خوبی ارائه می‌دهد.»',test3Title:'تجربه همکاری نمونه ۳',test3Role:'نمونه نمایشی',test4:'«جزئیات بصری و ساختار فنی با دقت اجرا شده و تغییرات درخواستی سریع اعمال شد.»',test4Title:'تجربه همکاری نمونه ۴',test4Role:'نمونه نمایشی',test5:'«ترکیب طراحی و توسعه در یک مسیر واحد باعث شد پروژه سریع‌تر و منسجم‌تر جلو برود.»',test5Title:'تجربه همکاری نمونه ۵',test5Role:'نمونه نمایشی',test6:'«عملکرد، ظاهر و نسخه موبایل هم‌زمان مورد توجه قرار گرفتند و خروجی یکپارچه بود.»',test6Title:'تجربه همکاری نمونه ۶',test6Role:'نمونه نمایشی',test7:'«ساختار پروژه مرتب و قابل توسعه است و برای ادامه کار پایه خوبی ایجاد می‌کند.»',test7Title:'تجربه همکاری نمونه ۷',test7Role:'نمونه نمایشی',test8:'«تعاملات صفحه و انیمیشن‌ها ظریف هستند و بدون شلوغ کردن طراحی، حس مدرن ایجاد می‌کنند.»',test8Title:'تجربه همکاری نمونه ۸',test8Role:'نمونه نمایشی',test9:'«توجه به تجربه کاربر و جزئیات کوچک، کیفیت نهایی محصول را کاملاً محسوس کرده است.»',test9Title:'تجربه همکاری نمونه ۹',test9Role:'نمونه نمایشی',test10:'«یک اجرای کامل و منظم که هم از نظر ظاهر و هم از نظر ساختار فنی قابل اتکا است.»',test10Title:'تجربه همکاری نمونه ۱۰',test10Role:'نمونه نمایشی'});
Object.assign(translations.en,{test1:'“Clean design, strong speed, and careful attention to detail; the result matched what we expected.”',test1Title:'Sample collaboration 1',test1Role:'Demo content',test2:'“The workflow was organized, from the first idea through final delivery, with every step easy to follow.”',test2Title:'Sample collaboration 2',test2Role:'Demo content',test3:'“The interface is professional and responsive, with a strong experience on mobile as well.”',test3Title:'Sample collaboration 3',test3Role:'Demo content',test4:'“Visual details and technical structure were handled carefully, and requested changes were applied quickly.”',test4Title:'Sample collaboration 4',test4Role:'Demo content',test5:'“Combining design and development in one workflow made the project faster and more consistent.”',test5Title:'Sample collaboration 5',test5Role:'Demo content',test6:'“Performance, visual quality, and mobile behavior were considered together for a coherent result.”',test6Title:'Sample collaboration 6',test6Role:'Demo content',test7:'“The project structure is clean and scalable, creating a solid foundation for future work.”',test7Title:'Sample collaboration 7',test7Role:'Demo content',test8:'“Subtle interactions and animations add a modern feel without making the design feel busy.”',test8Title:'Sample collaboration 8',test8Role:'Demo content',test9:'“Attention to user experience and small details made the final quality noticeably stronger.”',test9Title:'Sample collaboration 9',test9Role:'Demo content',test10:'“A complete and organized implementation that is reliable both visually and technically.”',test10Title:'Sample collaboration 10',test10Role:'Demo content'});
Object.assign(translations.ar,{test1:'«تصميم نظيف وسرعة جيدة واهتمام دقيق بالتفاصيل؛ النتيجة كانت قريبة جداً مما توقعناه.»',test1Title:'تجربة تعاون نموذجية ١',test1Role:'محتوى تجريبي',test2:'«كان سير العمل منظماً من الفكرة الأولى حتى التسليم النهائي، مع وضوح في كل خطوة.»',test2Title:'تجربة تعاون نموذجية ٢',test2Role:'محتوى تجريبي',test3:'«الواجهة احترافية ومتجاوبة وتقدم تجربة ممتازة على الهاتف أيضاً.»',test3Title:'تجربة تعاون نموذجية ٣',test3Role:'محتوى تجريبي',test4:'«تم تنفيذ التفاصيل البصرية والبنية التقنية بعناية، وتطبيق التعديلات بسرعة.»',test4Title:'تجربة تعاون نموذجية ٤',test4Role:'محتوى تجريبي',test5:'«جمع التصميم والتطوير ضمن مسار واحد جعل المشروع أسرع وأكثر اتساقاً.»',test5Title:'تجربة تعاون نموذجية ٥',test5Role:'محتوى تجريبي',test6:'«تمت مراعاة الأداء والمظهر وتجربة الهاتف معاً للحصول على نتيجة متكاملة.»',test6Title:'تجربة تعاون نموذجية ٦',test6Role:'محتوى تجريبي',test7:'«هيكل المشروع منظم وقابل للتوسع ويشكل أساساً جيداً للعمل المستقبلي.»',test7Title:'تجربة تعاون نموذجية ٧',test7Role:'محتوى تجريبي',test8:'«التفاعلات والحركات الهادئة تضيف إحساساً عصرياً دون ازدحام التصميم.»',test8Title:'تجربة تعاون نموذجية ٨',test8Role:'محتوى تجريبي',test9:'«الاهتمام بتجربة المستخدم والتفاصيل الصغيرة رفع جودة المنتج النهائي بشكل واضح.»',test9Title:'تجربة تعاون نموذجية ٩',test9Role:'محتوى تجريبي',test10:'«تنفيذ كامل ومنظم يمكن الاعتماد عليه بصرياً وتقنياً.»',test10Title:'تجربة تعاون نموذجية ١٠',test10Role:'محتوى تجريبي'});
Object.assign(translations.fa,{dashboardLabel:'AI / PWA / WEB',depthLabel:'عمق ۵بعدی',ticker:'رابط کاربری • وب‌اپلیکیشن • PWA • هوش مصنوعی • اتوماسیون • سئو • امنیت • عملکرد',portfolioKicker:'نمونه‌کارها',credentialsKicker:'مدارک',contactKicker:'تماس',locationsKicker:'موقعیت‌ها',aboutRole:'طراح و توسعه‌دهنده محصول دیجیتال',replaceCertificate:'با مدرک واقعی جایگزین شود',pwaBadge:'PWA',aiBadge:'هوش مصنوعی',globalBadge:'بین‌المللی',pwaTitle:'فروشگاه آفلاین PWA',aiTitle:'داشبورد دستیار هوش مصنوعی',globalTitle:'صفحه فرود محصول بین‌المللی',test1:'«نمونه متن آزمایشی — این بخش باید با نظر واقعی مشتری و نام کسب‌وکار جایگزین شود.»',test1Name:'مشتری نمونه',test1Role:'صاحب کسب‌وکار',test2:'«نمونه متن دوم برای نمایش اسلایدر؛ اطلاعات واقعی را جایگزین کنید.»',test2Name:'مشتری نمونه ۲',test2Role:'مدیر محصول',test3:'«ساختار آماده است و فقط کافی است نظرات واقعی مشتریان اضافه شوند.»',test3Name:'مشتری نمونه ۳',test3Role:'بنیان‌گذار',countryChoose:'انتخاب کشور',countryIran:'ایران',countryUae:'امارات',countryTurkey:'ترکیه',countryGermany:'آلمان',countryOther:'سایر',chooseOption:'انتخاب کنید',typeWebsite:'وب‌سایت',typeWebApp:'وب‌اپلیکیشن',typePwa:'PWA',typeAi:'هوش مصنوعی',typeAutomation:'اتوماسیون',typeSeo:'سئو / عملکرد',budgetEstimate:'نیاز به برآورد دارم',budgetLow:'کمتر از ۵۰۰ میلیون ریال',budgetMid:'۵۰۰ میلیون تا ۱ میلیارد ریال',budgetHigh:'بیش از ۱ میلیارد ریال',firstNamePlaceholder:'نام خود را وارد کنید',lastNamePlaceholder:'نام خانوادگی را وارد کنید',emailPlaceholder:'name@example.com',phonePlaceholder:'+98 ...',descriptionPlaceholder:'نیاز، هدف، زمان‌بندی و هر نکته مهم...',searchPlaceholder:'جستجو در سایت...',previewTab:'پیش‌نمایش',videoTab:'دموی ویدئویی',openMap:'باز کردن نقشه ↗',tehranSub:'تهران، ایران',karajTitle:'کرج — مهرشهر',karajAddress:'بلوار ارم، محدوده ساختمان تکنولوژی و هوش مصنوعی اپلیکیشن',copyright:'© {year} حسین منصوری — ساخته‌شده برای وب'});
Object.assign(translations.en,{dashboardLabel:'AI / PWA / WEB',depthLabel:'5D DEPTH',ticker:'UI/UX • WEB APP • PWA • AI • AUTOMATION • SEO • SECURITY • PERFORMANCE',portfolioKicker:'PORTFOLIO',credentialsKicker:'CREDENTIALS',contactKicker:'CONTACT',locationsKicker:'LOCATIONS',aboutRole:'Digital Product Designer & Developer',replaceCertificate:'Replace with real certificate',pwaBadge:'PWA',aiBadge:'AI',globalBadge:'GLOBAL',pwaTitle:'Offline Commerce PWA',aiTitle:'AI Assistant Dashboard',globalTitle:'Global Product Landing',test1:'“Demo text — replace this with a real client testimonial and business name.”',test1Name:'Sample Client',test1Role:'Business Owner',test2:'“Second slider sample — replace with real client information.”',test2Name:'Sample Client 2',test2Role:'Product Lead',test3:'“Structure is ready for real testimonials.”',test3Name:'Sample Client 3',test3Role:'Founder',countryChoose:'Select country',countryIran:'Iran',countryUae:'UAE',countryTurkey:'Turkey',countryGermany:'Germany',countryOther:'Other',chooseOption:'Choose',typeWebsite:'Website',typeWebApp:'Web App',typePwa:'PWA',typeAi:'AI',typeAutomation:'Automation',typeSeo:'SEO / Performance',budgetEstimate:'I need an estimate',budgetLow:'Under 500M IRR',budgetMid:'500M–1B IRR',budgetHigh:'Over 1B IRR',firstNamePlaceholder:'Enter your first name',lastNamePlaceholder:'Enter your last name',emailPlaceholder:'name@example.com',phonePlaceholder:'+98 ...',descriptionPlaceholder:'Needs, goals, timeline and important notes...',searchPlaceholder:'Search the site...',previewTab:'Preview',videoTab:'Video Demo',openMap:'Open map ↗',tehranSub:'Tehran, Iran',karajTitle:'Karaj — Mehrshahr',karajAddress:'Erm Boulevard, Technology & AI Application building area',copyright:'© {year} Hossein Mansouri — Built for web'});
Object.assign(translations.ar,{dashboardLabel:'AI / PWA / WEB',depthLabel:'عمق ثلاثي الأبعاد 5D',ticker:'واجهة المستخدم • تطبيق ويب • PWA • ذكاء اصطناعي • أتمتة • SEO • أمان • أداء',portfolioKicker:'الأعمال',credentialsKicker:'الشهادات',contactKicker:'اتصل',locationsKicker:'المواقع',aboutRole:'مصمم ومطور منتجات رقمية',replaceCertificate:'استبدلها بالشهادة الحقيقية',pwaBadge:'PWA',aiBadge:'ذكاء اصطناعي',globalBadge:'عالمي',pwaTitle:'متجر PWA يعمل دون اتصال',aiTitle:'لوحة مساعد الذكاء الاصطناعي',globalTitle:'صفحة منتج عالمية',test1:'«نص تجريبي — استبدله بتقييم عميل حقيقي واسم النشاط.»',test1Name:'عميل تجريبي',test1Role:'صاحب عمل',test2:'«نص تجريبي ثانٍ للشريط المنزلق — استبدله بمعلومات حقيقية.»',test2Name:'عميل تجريبي ٢',test2Role:'قائد منتج',test3:'«البنية جاهزة لإضافة تقييمات العملاء الحقيقية.»',test3Name:'عميل تجريبي ٣',test3Role:'مؤسس',countryChoose:'اختر الدولة',countryIran:'إيران',countryUae:'الإمارات',countryTurkey:'تركيا',countryGermany:'ألمانيا',countryOther:'أخرى',chooseOption:'اختر',typeWebsite:'موقع ويب',typeWebApp:'تطبيق ويب',typePwa:'PWA',typeAi:'ذكاء اصطناعي',typeAutomation:'أتمتة',typeSeo:'SEO / أداء',budgetEstimate:'أحتاج إلى تقدير',budgetLow:'أقل من 500 مليون ريال',budgetMid:'500 مليون إلى مليار ريال',budgetHigh:'أكثر من مليار ريال',firstNamePlaceholder:'أدخل الاسم',lastNamePlaceholder:'أدخل اسم العائلة',emailPlaceholder:'name@example.com',phonePlaceholder:'+98 ...',descriptionPlaceholder:'الاحتياج والأهداف والجدول الزمني وأي ملاحظات مهمة...',searchPlaceholder:'ابحث في الموقع...',previewTab:'معاينة',videoTab:'عرض الفيديو',openMap:'فتح الخريطة ↗',tehranSub:'طهران، إيران',karajTitle:'كرج — مهرشهر',karajAddress:'بلوار إرم، منطقة مبنى التكنولوجيا والذكاء الاصطناعي للتطبيقات',copyright:'© {year} حسين منصوري — صُمم للويب'});
let lang=localStorage.getItem('hm-lang')||'fa';function applyLang(){const t=translations[lang];document.documentElement.lang=lang;document.documentElement.dir=lang==='en'?'ltr':'rtl';$$('[data-i18n]').forEach(e=>{if(t[e.dataset.i18n])e.textContent=t[e.dataset.i18n]});$$('[data-placeholder-i18n]').forEach(e=>{if(t[e.dataset.placeholderI18n])e.placeholder=t[e.dataset.placeholderI18n]});document.title=(t.brand||'Hossein Mansouri')+' | '+(t.heroTitle||'Professional Web & Web App Designer');$$('[data-lang]').forEach(b=>b.classList.toggle('active',b.dataset.lang===lang));localStorage.setItem('hm-lang',lang);updateClock();}
$$('[data-lang]').forEach(b=>b.onclick=()=>{lang=b.dataset.lang;applyLang();updateDate()});
function updateClock(){const now=new Date();const loc=lang==='fa'?'fa-IR':lang==='ar'?'ar-SA':'en-US';const calLoc=lang==='fa'?'fa-IR-u-ca-persian':lang==='ar'?'ar-SA-u-ca-gregory':'en-US-u-ca-gregory';const time=new Intl.DateTimeFormat(loc,{hour:'2-digit',minute:'2-digit',second:'2-digit'}).format(now);const full=new Intl.DateTimeFormat(calLoc,{dateStyle:'full'}).format(now);const parts=new Intl.DateTimeFormat(calLoc,{day:'numeric',month:'long',year:'numeric'}).format(now);const weekday=new Intl.DateTimeFormat(calLoc,{weekday:'long'}).format(now);$('#clock').textContent=time;$('#date').textContent=full;if($('#heroClock'))$('#heroClock').textContent=time;if($('#heroDate'))$('#heroDate').textContent=parts;if($('#heroCalendar'))$('#heroCalendar').textContent=parts;if($('#heroWeekday'))$('#heroWeekday').textContent=weekday;updateDate(now)}function updateDate(now=new Date()){const loc=lang==='fa'?'fa-IR':lang==='ar'?'ar-SA':'en-US';$('#date').textContent=new Intl.DateTimeFormat(loc,{dateStyle:'full'}).format(now)}setInterval(updateClock,1000);updateClock();$('#year').textContent=new Date().getFullYear();
const menuBtn=$('#menuBtn'),nav=$('#nav');
if(menuBtn&&nav){
  menuBtn.setAttribute('aria-controls','nav');
  menuBtn.setAttribute('aria-expanded','false');
  const closeMenu=()=>{nav.classList.remove('open');menuBtn.setAttribute('aria-expanded','false');};
  const openMenu=()=>{nav.classList.add('open');menuBtn.setAttribute('aria-expanded','true');};
  menuBtn.addEventListener('click',e=>{
    e.preventDefault(); e.stopPropagation();
    nav.classList.contains('open')?closeMenu():openMenu();
  });
  nav.addEventListener('click',e=>{
    const item=e.target.closest('a,.nav-install-item');
    if(item && !item.classList.contains('nav-install-item')) closeMenu();
  });
  document.addEventListener('click',e=>{
    if(nav.classList.contains('open') && !nav.contains(e.target) && e.target!==menuBtn) closeMenu();
  });
  document.addEventListener('keydown',e=>{if(e.key==='Escape')closeMenu();});
}
$('#themeBtn').onclick=()=>{document.body.classList.toggle('light');localStorage.setItem('hm-theme',document.body.classList.contains('light')?'light':'dark')};if(localStorage.getItem('hm-theme')==='light')document.body.classList.add('light');
const audio=$('#ambientAudio');$('#musicBtn').onclick=async()=>{try{if(audio.paused){await audio.play();$('#musicBtn').textContent='♫';}else audio.pause()}catch(e){$('#formStatus').textContent='Audio requires a user gesture and a valid file.'}};
window.addEventListener('scroll',()=>{$('#progress').style.width=(scrollY/(document.documentElement.scrollHeight-innerHeight)*100)+'%';const y=scrollY+100;$$('main section[id]').forEach(s=>{const a=$(`.nav a[href="#${s.id}"]`);if(a)a.classList.toggle('active',s.offsetTop<=y&&s.offsetTop+s.offsetHeight>y)})},{passive:true});
const obs=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting&&e.target.matches('.stat')){const el=e.target.querySelector('[data-count]');if(el&&!el.dataset.done){el.dataset.done='1';const end=+el.dataset.count;let n=0;const step=Math.max(1,Math.ceil(end/40));const timer=setInterval(()=>{n=Math.min(end,n+step);el.textContent=n;if(n>=end)clearInterval(timer)},25)}}}),{threshold:.45});$$('.stat').forEach(s=>obs.observe(s));
let ti=0;const tests=$$('.testimonial'),dots=$$('#testDots button');function showTest(i){ti=(i+tests.length)%tests.length;tests.forEach((e,j)=>e.classList.toggle('active',j===ti));dots.forEach((e,j)=>e.classList.toggle('active',j===ti))}$('#prevTest').onclick=()=>showTest(ti-1);$('#nextTest').onclick=()=>showTest(ti+1);dots.forEach((d,i)=>d.onclick=()=>showTest(i));let testTimer=setInterval(()=>showTest(ti+1),5500);['prevTest','nextTest','testDots'].forEach(id=>$('#'+id)?.addEventListener('mouseenter',()=>clearInterval(testTimer)));$('#testimonialStage')?.addEventListener('mouseleave',()=>{clearInterval(testTimer);testTimer=setInterval(()=>showTest(ti+1),5500)});
const modal=$('#previewModal'),frame=$('#modalFrame'),video=$('#modalVideo');$$('.preview').forEach(btn=>btn.onclick=()=>{modal.classList.add('open');$('#modalTitle').textContent=btn.dataset.titleKey ? (translations[lang][btn.dataset.titleKey]||btn.dataset.titleKey) : btn.dataset.title;frame.src=btn.dataset.demo;video.src=btn.dataset.video;frame.hidden=false;video.hidden=true;$$('.modal-tabs button').forEach((b,i)=>b.classList.toggle('active',i===0))});$('#modalClose').onclick=()=>{modal.classList.remove('open');frame.src='about:blank';video.pause()};$$('.modal-tabs button').forEach(b=>b.onclick=()=>{const isV=b.dataset.tab==='video';frame.hidden=isV;video.hidden=!isV;$$('.modal-tabs button').forEach(x=>x.classList.toggle('active',x===b));if(!isV)video.pause()});
$('#searchBtn').onclick=()=>{$('#searchPanel').classList.add('open');$('#searchInput').focus()};$('#closeSearch').onclick=()=>$('#searchPanel').classList.remove('open');$('#searchInput').oninput=e=>{const q=e.target.value.trim().toLowerCase();const out=$('#searchResults');out.innerHTML='';if(!q)return;$$('h1,h2,h3,p').filter(x=>x.textContent.toLowerCase().includes(q)).slice(0,8).forEach(x=>{const d=document.createElement('div');d.className='search-result';d.textContent=x.textContent.slice(0,150);out.appendChild(d)})};
const form=$('#projectForm');function err(input,msg){const l=input.closest('label');l.classList.toggle('field-invalid',!!msg);l.querySelector('.error').textContent=msg||''}form.addEventListener('input',e=>{if(!e.target.name)return;const v=e.target.value.trim();if(e.target.required&&!v)err(e.target,'Required');else if(e.target.type==='email'&&v&&!/^\S+@\S+\.\S+$/.test(v))err(e.target,'Invalid email');else if(e.target.minLength&&v.length<e.target.minLength)err(e.target,`Minimum ${e.target.minLength} characters`);else err(e.target,'')});
form.onsubmit=async e=>{e.preventDefault();let ok=true;$$('[required]',form).forEach(i=>{const v=i.value.trim();let m='';if(!v)m='Required';else if(i.type==='email'&&!/^\S+@\S+\.\S+$/.test(v))m='Invalid email';else if(i.minLength&&v.length<i.minLength)m=`Minimum ${i.minLength} characters`;err(i,m);if(m)ok=false});if(!ok){$('#formStatus').textContent='Please fix the highlighted fields.';return}const data=Object.fromEntries(new FormData(form).entries());data.createdAt=new Date().toISOString();data.language=lang;data.location=$('#locationStatus').dataset.coords||'';localStorage.setItem('hm-project-'+Date.now(),JSON.stringify(data));if(C.projectEndpoint){try{await fetch(C.projectEndpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});$('#formStatus').textContent='Request sent successfully.'}catch(_){$('#formStatus').textContent='Saved locally; server endpoint failed.'}}else{$('#formStatus').textContent='Request saved on this device. Add projectEndpoint in config.js for server delivery.'}form.reset()};
let recognition=null;if('webkitSpeechRecognition'in window||'SpeechRecognition'in window){const SR=window.SpeechRecognition||window.webkitSpeechRecognition;recognition=new SR();recognition.continuous=true;recognition.interimResults=true;recognition.lang=lang==='fa'?'fa-IR':lang==='ar'?'ar-SA':'en-US';recognition.onstart=()=>{$('#listening').hidden=false;$('#voiceBtn').classList.add('active')};recognition.onend=()=>{$('#listening').hidden=true;$('#voiceBtn').classList.remove('active')};recognition.onerror=()=>{$('#listening').hidden=true;$('#formStatus').textContent='Microphone/Speech recognition error or permission denied.'};recognition.onresult=e=>{let s='';for(let i=e.resultIndex;i<e.results.length;i++)s+=e.results[i][0].transcript;$('#description').value=(($('#description').value+' '+s).trim());$('#description').dispatchEvent(new Event('input'))}}else $('#voiceBtn').title='Speech recognition is not supported in this browser';$('#voiceBtn').onclick=()=>{if(!recognition){$('#formStatus').textContent='Speech-to-Text is not supported in this browser.';return}recognition.lang=lang==='fa'?'fa-IR':lang==='ar'?'ar-SA':'en-US';if($('#listening').hidden)recognition.start();else recognition.stop()};
$('#locationBtn').onclick=()=>{if(!navigator.geolocation){$('#locationStatus').textContent='Geolocation not supported.';return}$('#locationStatus').textContent='Requesting permission…';navigator.geolocation.getCurrentPosition(p=>{const c=`${p.coords.latitude.toFixed(6)},${p.coords.longitude.toFixed(6)}`;$('#locationStatus').textContent=`Location: ${c}`;$('#locationStatus').dataset.coords=c},()=>$('#locationStatus').textContent='Location permission denied or unavailable.',{enableHighAccuracy:true,timeout:10000});};
applyLang();
})();

// Interactive micro-background: particles react to mouse/touch and stay lightweight.
(function(){
 const canvas=document.getElementById('mouseParticles'); if(!canvas)return;
 const ctx=canvas.getContext('2d'); let w=0,h=0,dpr=1,px=0,py=0,raf=0;
 const reduce=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 const particles=[];
 function resize(){dpr=Math.min(devicePixelRatio||1,2);w=innerWidth;h=innerHeight;canvas.width=w*dpr;canvas.height=h*dpr;canvas.style.width=w+'px';canvas.style.height=h+'px';ctx.setTransform(dpr,0,0,dpr,0,0);particles.length=0;const n=Math.min(85,Math.max(28,Math.floor(w*h/22000)));for(let i=0;i<n;i++)particles.push({x:Math.random()*w,y:Math.random()*h,vx:(Math.random()-.5)*.22,vy:(Math.random()-.5)*.22,r:Math.random()*2.4+.8,p:Math.random()*Math.PI*2})}
 function move(e){px=e.clientX;py=e.clientY}
 function draw(){ctx.clearRect(0,0,w,h);for(const p of particles){const dx=px-p.x,dy=py-p.y,dist=Math.hypot(dx,dy)||1;if(dist<180){p.vx+=dx/dist*.012;p.vy+=dy/dist*.012}p.vx*=.985;p.vy*=.985;p.x+=p.vx;p.y+=p.vy;if(p.x<0)p.x=w;if(p.x>w)p.x=0;if(p.y<0)p.y=h;if(p.y>h)p.y=0;p.p+=.018;const a=.16+.12*Math.sin(p.p);ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);ctx.fillStyle=`rgba(255,45,45,${a})`;ctx.fill();if(dist<120){ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(px,py);ctx.strokeStyle=`rgba(255,45,45,${.09*(1-dist/120)})`;ctx.stroke()}}raf=requestAnimationFrame(draw)}
 if(!reduce){addEventListener('resize',resize,{passive:true});addEventListener('pointermove',move,{passive:true});resize();draw()}else canvas.remove();
 const halo=document.getElementById('cursorHalo'); if(halo&&!reduce){addEventListener('pointermove',e=>{halo.style.transform=`translate(${e.clientX}px,${e.clientY}px) translate(-50%,-50%)`},{passive:true})}
})();

// Inline field feedback + online/offline email status.
(function(){
 const form=document.getElementById('projectForm'); if(!form)return;
 const email=form.querySelector('input[name="email"]'), emailStatus=document.getElementById('emailStatus'), emailField=email?.closest('.email-field');
 function emailCheck(){
  if(!email||!emailStatus)return;
  const v=email.value.trim();
  const online=navigator.onLine;
  if(!v){emailStatus.textContent=''; emailStatus.className='field-state'; emailField?.classList.toggle('offline',!online); return}
  if(!online){emailStatus.textContent='Offline — اتصال اینترنت را بررسی کنید';emailStatus.className='field-state warn';emailField?.classList.add('offline');return}
  if(/^\S+@\S+\.\S+$/.test(v)){emailStatus.textContent='Online ✓ — فرمت ایمیل معتبر است';emailStatus.className='field-state ok';emailField?.classList.remove('offline')}
  else{emailStatus.textContent='فرمت ایمیل را بررسی کنید';emailStatus.className='field-state bad';emailField?.classList.remove('offline')}
 }
 email?.addEventListener('input',emailCheck); addEventListener('online',emailCheck); addEventListener('offline',emailCheck); emailCheck();
 form.querySelectorAll('input,select,textarea').forEach(el=>el.addEventListener('focus',()=>el.closest('.field-shell')?.classList.add('focused')));
})();


/* ===== V5 ENHANCEMENTS: LIVE CLOCK/DATE, HAND ORB PARALLAX & HEADER LANG SYNC ===== */
document.addEventListener('DOMContentLoaded', () => {
  const allLangBtns = document.querySelectorAll('.lang-btn, [data-lang]');
  function updateLangUI(lang) {
    document.querySelectorAll('.lang-btn, [data-lang]').forEach(btn => {
      if (btn.getAttribute('data-lang') === lang) {
        btn.classList.add('active');
        btn.setAttribute('aria-pressed', 'true');
      } else {
        btn.classList.remove('active');
        btn.setAttribute('aria-pressed', 'false');
      }
    });
  }

  allLangBtns.forEach(btn => {
    btn.addEventListener('click', (e) => {
      const selectedLang = btn.getAttribute('data-lang');
      if (selectedLang) {
        if (typeof window.setLanguage === 'function') {
          window.setLanguage(selectedLang);
        } else if (typeof setLanguage === 'function') {
          setLanguage(selectedLang);
        }
        updateLangUI(selectedLang);
      }
    });
  });

  const timeElements = document.querySelectorAll('.live-time, #liveTime, #headerTime, [data-live-time]');
  const dateElements = document.querySelectorAll('.live-date, #liveDate, #headerDate, [data-live-date]');

  function updateLiveClockAndDate() {
    const now = new Date();
    const currentLang = document.documentElement.lang || localStorage.getItem('portfolio_lang') || 'fa';

    let timeStr = '';
    let dateStr = '';

    if (currentLang === 'fa') {
      timeStr = now.toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
      dateStr = new Intl.DateTimeFormat('fa-IR-u-ca-persian', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(now);
    } else if (currentLang === 'ar') {
      timeStr = now.toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
      dateStr = new Intl.DateTimeFormat('ar-SA', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(now);
    } else {
      timeStr = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
      dateStr = new Intl.DateTimeFormat('en-US', { weekday: 'long', day: 'numeric', month: 'short', year: 'numeric' }).format(now);
    }

    timeElements.forEach(el => { el.textContent = timeStr; });
    dateElements.forEach(el => { el.textContent = dateStr; });
  }

  setInterval(updateLiveClockAndDate, 1000);
  updateLiveClockAndDate();

  const heroSection = document.querySelector('.hero-section') || document.querySelector('.hero');
  const handOrb = document.getElementById('handHologramOrb');

  if (heroSection && handOrb) {
    let targetX = 0, targetY = 0;
    let currentX = 0, currentY = 0;

    heroSection.addEventListener('mousemove', (e) => {
      const rect = heroSection.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width - 0.5;
      const y = (e.clientY - rect.top) / rect.height - 0.5;
      targetX = x * 35;
      targetY = y * 35;
    });

    heroSection.addEventListener('mouseleave', () => {
      targetX = 0;
      targetY = 0;
    });

    /* Mobile touch parallax disabled: native scrolling stays stable. */
  }

  const statNumbers = document.querySelectorAll('.stat-number, [data-target]');
  if (statNumbers.length > 0) {
    statNumbers.forEach(stat => {
      const target = parseInt(stat.getAttribute('data-target') || stat.textContent.replace(/[^0-9]/g, ''), 10);
      if (target && !isNaN(target)) {
        let count = 0;
        const step = Math.max(1, Math.ceil(target / 40));
        const timer = setInterval(() => {
          count += step;
          if (count >= target) {
            stat.textContent = target + '+';
            clearInterval(timer);
          } else {
            stat.textContent = count + '+';
          }
        }, 30);
      }
    });
  }
});

/* ===== DIRECTION TOGGLE SCRIPT ===== */
document.addEventListener("DOMContentLoaded", () => {
  const dirBtn = document.getElementById("dirToggleBtn");
  const dirText = document.getElementById("dirBtnText");
  const htmlRoot = document.documentElement;
  function setDir(d) {
    htmlRoot.setAttribute("dir", d);
    if (dirText) dirText.textContent = d.toUpperCase();
    localStorage.setItem("portfolio_dir", d);
  }
  const savedDir = localStorage.getItem("portfolio_dir");
  if (savedDir) {
    setDir(savedDir);
  } else {
    const initialDir = htmlRoot.getAttribute("dir") || "rtl";
    if (dirText) dirText.textContent = initialDir.toUpperCase();
  }
  if (dirBtn) {
    dirBtn.addEventListener("click", () => {
      const curr = htmlRoot.getAttribute("dir") || "rtl";
      setDir(curr === "rtl" ? "ltr" : "rtl");
    });
  }
});

/* ===== FINAL POLISH: real calendar systems + 10-card slider + command center ===== */
document.addEventListener('DOMContentLoaded',()=>{
  const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
  const stage=$('#testimonialStage'), slides=$$('.testimonial-stage .testimonial'), dots=$$('#testDots button');
  let slide=0;
  function showSlide(n){if(!slides.length)return;slide=(n+slides.length)%slides.length;slides.forEach((el,i)=>el.classList.toggle('active',i===slide));dots.forEach((d,i)=>d.classList.toggle('active',i===slide));}
  $('#prevTest')?.addEventListener('click',()=>showSlide(slide-1));$('#nextTest')?.addEventListener('click',()=>showSlide(slide+1));dots.forEach(d=>d.addEventListener('click',()=>showSlide(+d.dataset.slide||0)));
  let sx=0;stage?.addEventListener('touchstart',e=>sx=e.changedTouches[0].screenX,{passive:true});stage?.addEventListener('touchend',e=>{const dx=e.changedTouches[0].screenX-sx;if(Math.abs(dx)>45)showSlide(slide+(dx<0?1:-1));},{passive:true});showSlide(0);
  function updateCalendar(){const now=new Date(),lang=document.documentElement.lang||'fa';let locale,opts,dateEl=$('#heroDate'),calEl=$('#heroCalendar'),dayEl=$('#heroWeekday'),footer=$('#date');
    if(lang==='fa'){locale='fa-IR';opts={calendar:'persian',dateStyle:'full'};}else if(lang==='ar'){locale='ar-SA-u-ca-islamic-umalqura';opts={calendar:'islamic-umalqura',dateStyle:'full'};}else{locale='en-US';opts={calendar:'gregory',dateStyle:'full'};}
    const date=new Intl.DateTimeFormat(locale,opts).format(now), weekday=new Intl.DateTimeFormat(locale,{weekday:'long',calendar:opts.calendar}).format(now), time=new Intl.DateTimeFormat(locale,{hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(now);
    $('#clock')?.replaceChildren(document.createTextNode(time));$('#heroClock')?.replaceChildren(document.createTextNode(time));dateEl?.replaceChildren(document.createTextNode(date));calEl?.replaceChildren(document.createTextNode(date));dayEl?.replaceChildren(document.createTextNode(weekday));footer?.replaceChildren(document.createTextNode(date));$('#year')?.replaceChildren(document.createTextNode(new Intl.DateTimeFormat('en',{year:'numeric'}).format(now)));
  }
  updateCalendar();setInterval(updateCalendar,1000);
  const fab=$('#commandFab'),panel=$('#commandPanel');function toggle(open){panel?.classList.toggle('open',open);panel?.setAttribute('aria-hidden',String(!open));fab?.setAttribute('aria-expanded',String(open));}
  fab?.addEventListener('click',()=>toggle(!panel?.classList.contains('open')));$('#commandClose')?.addEventListener('click',()=>toggle(false));document.addEventListener('click',e=>{if(panel?.classList.contains('open')&&!panel.contains(e.target)&&e.target!==fab)toggle(false)});
  $$('.command-grid button').forEach(b=>b.addEventListener('click',()=>{const c=b.dataset.command;if(c==='theme')$('#themeBtn')?.click();if(c==='music')$('#musicBtn')?.click();if(c==='install')$('#installBtn')?.click();if(c==='search')$('#searchBtn')?.click();}));
});


/* Persistent text-size control: immediate touch response, four sizes. */
(()=>{
 const root=document.documentElement, key='hm-text-size';
 const allowed=['small','medium','large','xlarge'];
 const apply=v=>{
   v=allowed.includes(v)?v:'medium';
   root.dataset.textSize=v;
   try{localStorage.setItem(key,v)}catch(_){}
   document.querySelectorAll('[data-text-size]').forEach(b=>{
     b.setAttribute('aria-pressed',b.dataset.textSize===v?'true':'false');
   });
 };
 apply((()=>{try{return localStorage.getItem(key)}catch(_){return null}})()||'medium');
 document.addEventListener('click',e=>{
   const b=e.target.closest('[data-text-size]');
   if(!b||!allowed.includes(b.dataset.textSize)) return;
   e.preventDefault();e.stopPropagation();apply(b.dataset.textSize);
 });
})();


/* V6: multilingual app update */
(()=>{
 const labels={fa:'بروزرسانی اپلیکیشن',en:'Update app',ar:'تحديث التطبيق'};
 const updateLabel=()=>{
   const l=document.documentElement.lang||'fa';
   document.querySelectorAll('[data-i18n="updateApp"]').forEach(el=>{
     el.textContent=labels[l]||labels.fa;
   });
 };
 const updateApp=async()=>{
   try{
     if(!('serviceWorker' in navigator)){ location.reload(); return; }
     const reg=await navigator.serviceWorker.getRegistration('./');
     if(!reg){ location.reload(); return; }
     await reg.update();
     if(reg.waiting){
       reg.waiting.postMessage({type:'SKIP_WAITING'});
       setTimeout(()=>location.reload(),300);
     }else{
       location.reload();
     }
   }catch(e){ location.reload(); }
 };
 document.addEventListener('click',e=>{
   const el=e.target.closest('[data-command="update"],#updateBtn');
   if(!el)return;
   e.preventDefault();
   updateApp();
 });
 updateLabel();
 new MutationObserver(updateLabel).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
})();

/* V7: all visible install/update/text-size labels follow the active language. */
(()=>{
 const map={
  fa:{install:'نصب اپلیکیشن',update:'بروزرسانی اپلیکیشن',size:'اندازه متن',small:'ریز',medium:'متوسط',large:'بزرگ',xlarge:'خیلی بزرگ'},
  en:{install:'Install app',update:'Update app',size:'Text size',small:'Small',medium:'Medium',large:'Large',xlarge:'Very large'},
  ar:{install:'تثبيت التطبيق',update:'تحديث التطبيق',size:'حجم النص',small:'صغير',medium:'متوسط',large:'كبير',xlarge:'كبير جدًا'}
 };
 const sync=()=>{
  const l=document.documentElement.lang||'fa', t=map[l]||map.fa;
  document.querySelectorAll('[data-i18n="installApp"]').forEach(e=>e.textContent=t.install);
  document.querySelectorAll('[data-i18n="quickInstall"]').forEach(e=>e.textContent=t.install);
  document.querySelectorAll('[data-i18n="updateApp"],[data-i18n="quickUpdate"]').forEach(e=>e.textContent=t.update);
  document.querySelectorAll('[data-i18n="textSizeLabel"]').forEach(e=>e.textContent=t.size);
  document.querySelectorAll('[data-i18n="textSmall"]').forEach(e=>e.textContent=t.small);
  document.querySelectorAll('[data-i18n="textMedium"]').forEach(e=>e.textContent=t.medium);
  document.querySelectorAll('[data-i18n="textLarge"]').forEach(e=>e.textContent=t.large);
  document.querySelectorAll('[data-i18n="textXLarge"]').forEach(e=>e.textContent=t.xlarge);
 };
 sync();
 new MutationObserver(sync).observe(document.documentElement,{attributes:true,attributeFilter:['lang']});
})();
