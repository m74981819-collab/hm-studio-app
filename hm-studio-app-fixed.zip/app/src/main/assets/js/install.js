/* NOR V10 — direct native PWA install when the browser exposes it; never show a fake alert */
(() => {
  const buttons = [
    document.getElementById("installBtn"),
    ...document.querySelectorAll('[data-command="install"]')
  ].filter(Boolean);
  if (!buttons.length) return;

  let deferredPrompt = null;
  const standalone = () =>
    window.matchMedia("(display-mode: standalone)").matches ||
    window.navigator.standalone === true;

  const setReady = (ready) => {
    buttons.forEach((b) => {
      b.classList.toggle("install-ready", ready);
      b.setAttribute("aria-disabled", ready ? "false" : "true");
    });
  };

  if (standalone()) {
    buttons.forEach((b) => (b.hidden = true));
    return;
  }

  setReady(false);

  window.addEventListener("beforeinstallprompt", (event) => {
    event.preventDefault();
    deferredPrompt = event;
    setReady(true);
  });

  window.addEventListener("appinstalled", () => {
    deferredPrompt = null;
    buttons.forEach((b) => (b.hidden = true));
  });

  async function install() {
    if (!deferredPrompt) return;
    const event = deferredPrompt;
    deferredPrompt = null;
    setReady(false);
    try {
      event.prompt();
      await event.userChoice;
    } catch (_) {}
  }

  window.NORInstallApp = install;
  buttons.forEach((b) => b.addEventListener("click", (e) => {
    e.preventDefault();
    install();
  }));
})();
