package com.hmstudio.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

/** HM Studio Android WebView shell with native intents, permissions, sharing and location support. */
public class MainActivity extends Activity {
    private static final String START_URL = "file:///android_asset/index.html";
    private static final int COLOR_BG = 0xFF06111F;
    private static final int REQ_LOCATION = 1001;
    private static final int REQ_CALL = 1002;
    private static final int REQ_AUDIO = 1003;

    private WebView webView;
    private LinearLayout bottomBar;
    private String pendingTel;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;
    private PermissionRequest pendingWebPermission;

    private static final String[] SECTION_IDS = {"home", "services", "portfolio", "testimonials", "contact"};
    private static final String[] SECTION_LABELS = {"خانه", "خدمات", "نمونه‌کار", "نظرات", "تماس"};

    @SuppressLint("SetJavaScriptEnabled")
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setBackgroundColor(COLOR_BG);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(COLOR_BG);
        webView = new WebView(this);
        webView.setBackgroundColor(COLOR_BG);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setVerticalScrollBarEnabled(false);
        webView.setHorizontalScrollBarEnabled(false);
        configureWebSettings(webView.getSettings());
        configureClients();
        webView.addJavascriptInterface(new NativeBridge(), "HMNative");

        FrameLayout.LayoutParams webLp = new FrameLayout.LayoutParams(-1, -1);
        root.addView(webView, webLp);
        bottomBar = buildBottomBar();
        FrameLayout.LayoutParams barLp = new FrameLayout.LayoutParams(-1, dp(58));
        barLp.gravity = Gravity.BOTTOM;
        root.addView(bottomBar, barLp);
        setContentView(root);
        applySafeAreaInsets(root);

        if (savedInstanceState != null) webView.restoreState(savedInstanceState);
        else webView.loadUrl(START_URL);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebSettings(WebSettings s) {
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setTextZoom(100);
    }

    private void configureClients() {
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return openExternal(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return openExternal(Uri.parse(url));
            }
            private boolean openExternal(Uri uri) {
                if (uri == null) return true;
                String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase();
                if ("file".equals(scheme)) return false;
                if ("tel".equals(scheme)) { dial(uri.toString()); return true; }
                if ("mailto".equals(scheme)) { openIntent(new Intent(Intent.ACTION_SENDTO, uri)); return true; }
                openIntent(new Intent(Intent.ACTION_VIEW, uri));
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript("(function(){var st=document.createElement('style');st.id='native-no-anim';st.textContent='*,*::before,*::after{animation:none!important;transition:none!important;animation-duration:0s!important;transition-duration:0s!important;scroll-behavior:auto!important;}html{scroll-behavior:auto!important;overscroll-behavior:none}';document.head.appendChild(st);['redParticles','mouseParticles'].forEach(function(id){var c=document.getElementById(id);if(c)c.style.display='none'});var sp=document.getElementById('mouseSpotlight');if(sp)sp.style.display='none';})();", null);
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, true, false);
                } else {
                    pendingGeoOrigin = origin; pendingGeoCallback = callback;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOCATION);
                }
            }
            @Override public void onPermissionRequest(PermissionRequest request) {
                String[] resources = request.getResources();
                boolean audio = false;
                for (String r : resources) if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) audio = true;
                if (audio && Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    pendingWebPermission = request;
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
                } else {
                    request.grant(resources);
                }
            }
        });
    }

    private void dial(String tel) {
        pendingTel = tel;
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, REQ_CALL);
            return;
        }
        try { startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(tel))); }
        catch (Exception e) { openIntent(new Intent(Intent.ACTION_DIAL, Uri.parse(tel))); }
    }

    private void openIntent(Intent intent) {
        try { startActivity(intent); }
        catch (Exception e) { Toast.makeText(this, "برنامه مناسب برای این لینک روی گوشی پیدا نشد.", Toast.LENGTH_SHORT).show(); }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean ok = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
        if (requestCode == REQ_CALL) { if (ok && pendingTel != null) { try { startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(pendingTel))); } catch (Exception e) { openIntent(new Intent(Intent.ACTION_DIAL, Uri.parse(pendingTel))); } } pendingTel = null; }
        else if (requestCode == REQ_LOCATION) { if (pendingGeoCallback != null) pendingGeoCallback.invoke(pendingGeoOrigin, ok, false); pendingGeoCallback = null; pendingGeoOrigin = null; }
        else if (requestCode == REQ_AUDIO) { if (pendingWebPermission != null) { if (ok) pendingWebPermission.grant(pendingWebPermission.getResources()); else pendingWebPermission.deny(); } pendingWebPermission = null; }
    }

    private LinearLayout buildBottomBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setBackgroundColor(COLOR_BG);
        for (int i=0;i<SECTION_IDS.length;i++) {
            final String section=SECTION_IDS[i];
            Button b=new Button(this,null,0); b.setText(SECTION_LABELS[i]); b.setAllCaps(false); b.setTextSize(12f); b.setTextColor(Color.WHITE); b.setBackgroundColor(Color.TRANSPARENT); b.setOnClickListener(v->jumpTo(section));
            bar.addView(b,new LinearLayout.LayoutParams(0,-1,1f));
        }
        return bar;
    }
    private void jumpTo(String id) { if(webView!=null) webView.evaluateJavascript("(function(){var e=document.getElementById('"+id+"');if(e)e.scrollIntoView({behavior:'auto',block:'start'});})();",null); }

    private void applySafeAreaInsets(FrameLayout root) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            root.setOnApplyWindowInsetsListener((v,insets)->{ android.graphics.Insets sys=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout()); webView.setPadding(0,sys.top,0,0); bottomBar.setPadding(0,0,0,sys.bottom); bottomBar.getLayoutParams().height=dp(58)+sys.bottom; bottomBar.requestLayout(); return WindowInsets.CONSUMED; });
        }
    }

    private class NativeBridge {
        @android.webkit.JavascriptInterface public void share() {
            Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_SUBJECT,"HM Studio"); i.putExtra(Intent.EXTRA_TEXT,"HM Studio — وب‌اپ و اپلیکیشن استودیو نور"); openIntent(Intent.createChooser(i,"اشتراک‌گذاری"));
        }
        @android.webkit.JavascriptInterface public void installApp() {
            Toast.makeText(MainActivity.this,"این نسخه Android همین حالا روی گوشی نصب است.",Toast.LENGTH_SHORT).show();
        }
        @android.webkit.JavascriptInterface public void updateApp() {
            openIntent(new Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/m74981819-collab/hm-studio-app/releases")));
        }
        @android.webkit.JavascriptInterface public void openMap(double lat,double lng) {
            openIntent(new Intent(Intent.ACTION_VIEW, Uri.parse("geo:"+lat+","+lng+"?q="+lat+","+lng)));
        }
        @android.webkit.JavascriptInterface public void call(String number) { dial("tel:"+number); }
        @android.webkit.JavascriptInterface public void email(String address) { openIntent(new Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:"+address))); }
    }

    @Override protected void onSaveInstanceState(Bundle outState){super.onSaveInstanceState(outState);if(webView!=null)webView.saveState(outState);}
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){if(webView!=null){webView.loadUrl("about:blank");webView.removeAllViews();webView.destroy();webView=null;}super.onDestroy();}
    private int dp(int v){return Math.round(v*getResources().getDisplayMetrics().density);}
}
