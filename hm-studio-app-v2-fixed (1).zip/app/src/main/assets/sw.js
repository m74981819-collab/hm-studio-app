const CACHE = 'hm-studio-v6';
const PRECACHE = [
  './','./index.html','./css/styles.css','./css/red-effects.css',
  './js/app.js','./js/config.js','./js/red-effects.js','./manifest.webmanifest',
  './assets/favicon.svg','./assets/icons/icon-192.png','./assets/icons/icon-512.png','./assets/icons/icon-maskable.png',
  './assets/images/hossein-hero.png','./assets/images/hossein-secondary.png',
  './assets/demos/pwa-demo.html','./assets/demos/ai-demo.html','./assets/demos/global-demo.html'
];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(PRECACHE)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});
self.addEventListener('fetch', event => {
  if(event.request.method!=='GET') return;
  const url=new URL(event.request.url);
  if(url.origin!==location.origin) return;
  if(event.request.mode==='navigate'){
    event.respondWith(fetch(event.request).catch(()=>caches.match('./index.html')));
    return;
  }
  event.respondWith(
    caches.match(event.request).then(cached => {
      const network=fetch(event.request).then(response=>{
        if(response.ok && response.type==='basic'){
          const copy=response.clone();
          caches.open(CACHE).then(c=>c.put(event.request,copy));
        }
        return response;
      }).catch(()=>cached);
      return cached || network;
    })
  );
});
