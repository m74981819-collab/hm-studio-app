# Hossein Mansouri Portfolio — Ready-to-upload static site

## Quick install
1. Extract the ZIP.
2. Upload the contents of `hossein-mansouri-portfolio/` to your web root (`public_html`, `www`, etc.).
3. Open through HTTPS. PWA, geolocation and microphone features require HTTPS (localhost is also okay).
4. No Node/npm/build step is required.

## Configure before launch
Edit `js/config.js` and replace `YOUR_EMAIL@example.com`, `YOUR_TELEGRAM_USERNAME`, and optionally `projectEndpoint` for server-side form delivery.

## Included
FA/EN/AR language switching, RTL/LTR, localized live clock/date, dark/light theme, fixed responsive header, glassmorphism, animated 3D-style digital scene, your two photos, UI/UX/Web App/PWA/Offline/AI/Automation/SEO/Security/Performance/Support services, interactive demos, MP4 video demos, animated stats, skills, certificates placeholders, testimonial slider, validated project form, multilingual browser Speech-to-Text, listening orb, reduced-motion support, geolocation permission, Tehran/Karaj map, WhatsApp/Telegram/Email links, PWA manifest/service worker/offline cache, site search and ambient audio control.

## Form delivery
If `projectEndpoint` is empty, submissions are saved locally in the browser. If set, the frontend sends JSON POST to that HTTPS endpoint. Validate and sanitize on the server.

## Security
Never put secrets/API keys in frontend files. Use HTTPS and server-side validation/rate limiting for production.
