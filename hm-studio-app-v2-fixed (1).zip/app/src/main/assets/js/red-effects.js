/* NORStudio — gold magnetic background particles. Never paints inside UI/media. */
(() => {
  const canvas = document.getElementById('redParticles');
  if (!canvas) return;
  const ctx = canvas.getContext('2d', { alpha: true });
  if (!ctx) return;
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let w = 0, h = 0, dpr = 1, particles = [];
  let mx = -9999, my = -9999, active = false;
  const GOLD = '#f6c453', GOLD_RGB = '246,196,83';
  const blockedSelectors = 'img,video,iframe,.glass-card,.stat,.service,.project,.achievement-card,.testimonial,.about-image,.hero-photo-wrap,.screen,.glass-console,.data-orb,.image-caption,input,textarea,select,button,.modal,.command-panel';
  let blocked = [];

  function refreshBlocked() {
    blocked = [...document.querySelectorAll(blockedSelectors)].map(el => {
      const r = el.getBoundingClientRect();
      return {l:r.left-8,t:r.top-8,r:r.right+8,b:r.bottom+8};
    });
  }
  function lineHitsBlocked(x1,y1,x2,y2){for(const r of blocked){const steps=Math.max(4,Math.ceil(Math.hypot(x2-x1,y2-y1)/12));for(let k=1;k<steps;k++){const t=k/steps,x=x1+(x2-x1)*t,y=y1+(y2-y1)*t;if(x>=r.l&&x<=r.r&&y>=r.t&&y<=r.b)return true;}}return false;}
  function insideBlocked(x, y) {
    for (const r of blocked) if (x >= r.l && x <= r.r && y >= r.t && y <= r.b) return true;
    return false;
  }
  function resize() {
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    w = innerWidth; h = innerHeight;
    canvas.width = Math.round(w*dpr); canvas.height = Math.round(h*dpr);
    canvas.style.width = w+'px'; canvas.style.height = h+'px';
    ctx.setTransform(dpr,0,0,dpr,0,0);
    const count = Math.min(78, Math.max(32, Math.floor(w/15)));
    particles = Array.from({length:count}, () => ({
      x: Math.random()*w, y: Math.random()*h,
      vx:(Math.random()-.5)*.18, vy:(Math.random()-.5)*.18,
      r:1.5+Math.random()*2.1, a:.48+Math.random()*.45
    }));
    refreshBlocked();
  }
  function pointer(x,y){ mx=x; my=y; active=true; }
  addEventListener('resize', resize, {passive:true});
  addEventListener('scroll', refreshBlocked, {passive:true});
  addEventListener('mousemove', e => pointer(e.clientX,e.clientY), {passive:true});
  addEventListener('touchstart', e => { const t=e.touches[0]; if(t) pointer(t.clientX,t.clientY); }, {passive:true});
  addEventListener('touchmove', e => { const t=e.touches[0]; if(t) pointer(t.clientX,t.clientY); }, {passive:true});
  addEventListener('mouseleave', () => { active=false; mx=-9999; my=-9999; }, {passive:true});

  function draw() {
    ctx.clearRect(0,0,w,h);
    for (const p of particles) {
      if (active) {
        const dx=mx-p.x, dy=my-p.y, dist=Math.hypot(dx,dy);
        if (dist < 320 && dist > 1) {
          const f = (1-dist/320) * 0.18;
          p.vx += dx/dist*f; p.vy += dy/dist*f;
        }
      }
      p.vx*=.965; p.vy*=.965;
      p.x+=p.vx; p.y+=p.vy;
      if(p.x < -20) p.x=w+20; if(p.x>w+20) p.x=-20;
      if(p.y < -20) p.y=h+20; if(p.y>h+20) p.y=-20;
      if (insideBlocked(p.x,p.y)) continue;
      ctx.beginPath(); ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
      ctx.fillStyle=`rgba(${GOLD_RGB},${p.a})`;
      ctx.shadowBlur=12; ctx.shadowColor=GOLD; ctx.fill();
    }
    // Particle-to-particle magnetic network, skipped whenever either endpoint is UI/media.
    for(let i=0;i<particles.length;i++){
      const a=particles[i]; if(insideBlocked(a.x,a.y)) continue;
      for(let j=i+1;j<particles.length;j++){
        const b=particles[j]; if(insideBlocked(b.x,b.y)) continue;
        const d=Math.hypot(a.x-b.x,a.y-b.y);
        if(d<150 && !lineHitsBlocked(a.x,a.y,b.x,b.y)){
          ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);
          ctx.strokeStyle=`rgba(${GOLD_RGB},${.48*(1-d/150)})`;ctx.lineWidth=1;ctx.stroke();
        }
      }
    }
    // Strong visible adhesion to the pointer.
    if(active && mx>-1000){
      for(const p of particles){
        if(insideBlocked(p.x,p.y)) continue;
        const d=Math.hypot(p.x-mx,p.y-my);
        if(d<260 && !lineHitsBlocked(p.x,p.y,mx,my)){
          ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(mx,my);
          ctx.strokeStyle=`rgba(${GOLD_RGB},${.58*(1-d/260)})`;ctx.lineWidth=1.15;ctx.stroke();
        }
      }
    }
    if(!reduce) requestAnimationFrame(draw);
  }
  resize(); draw();
  // Recalculate exclusions after images/fonts/layout settle.
  setTimeout(refreshBlocked, 500);
  setTimeout(refreshBlocked, 1500);
})();
