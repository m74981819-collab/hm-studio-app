window.SITE_CONFIG = {
  name: 'حسین منصوری',
  phone: '+989399020094',
  phoneDisplay: '+98 939 902 0094',
  email: 'm74981819@gmail.com',
  whatsapp: 'https://wa.me/989399020094',
  telegram: '+989399020094',
  locations: {
    tehran: { label: 'تهران', lat: 35.6892, lng: 51.3890 },
    karaj: { label: 'کرج، مهرشهر، بلوار ارم', lat: 35.8400, lng: 50.9391 }
  },
  projectEndpoint: '', // Optional: set your Formspree/Apps Script/API endpoint for real server delivery.
  social: {
    whatsapp: 'https://wa.me/989399020094',
    telegram: 'https://t.me/+989399020094',
    email: 'm74981819@gmail.com'
  }
};
