/* Native Android + browser install support. */
(() => {
  const buttons = [document.getElementById("installBtn"), ...document.querySelectorAll('[data-command="install"]')].filter(Boolean);
  if (!buttons.length) return;
  const native = () => !!window.HMNative;
  let deferredPrompt = null;
  const standalone = () => window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true;
  const setReady = ready => buttons.forEach(b => b.setAttribute("aria-disabled", ready ? "false" : "true"));
  if (native()) { setReady(true); buttons.forEach(b => b.addEventListener("click", e => { e.preventDefault(); window.HMNative.installApp(); })); return; }
  if (standalone()) { buttons.forEach(b => b.hidden = true); return; }
  setReady(false);
  window.addEventListener("beforeinstallprompt", e => { e.preventDefault(); deferredPrompt=e; setReady(true); });
  window.addEventListener("appinstalled", () => { deferredPrompt=null; buttons.forEach(b=>b.hidden=true); });
  buttons.forEach(b=>b.addEventListener("click", async e=>{e.preventDefault(); if(!deferredPrompt)return; const p=deferredPrompt; deferredPrompt=null; setReady(false); try{p.prompt();await p.userChoice}catch(_){} }));
})();
