Optional: put your own ambient MP3 here as ambient.mp3
