Optional demo videos: pwa-demo.mp4, ai-demo.mp4, global-demo.mp4
