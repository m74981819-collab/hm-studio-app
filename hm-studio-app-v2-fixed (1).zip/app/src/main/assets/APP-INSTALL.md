# HM Studio — نصب اپلیکیشن

این پروژه به‌صورت **PWA** آماده شده و روی HTTPS (مثل Netlify) قابل نصب است.

- Android/Chrome: دکمه «نصب اپلیکیشن» را بزنید.
- iPhone/iPad/Safari: Share → Add to Home Screen
- Desktop Chrome/Edge: Install App از نوار آدرس یا دکمه سایت
- پس از نصب، برنامه در حالت standalone باز می‌شود.
- آفلاین: پوسته اصلی و فایل‌های اصلی سایت از Service Worker قابل دسترسی هستند.

نکته: PWA یک اپلیکیشن وب نصب‌شونده است و بدون ساخت APK/AAB جداگانه روی چند پلتفرم اجرا می‌شود.
