# فهرست شخصی‌سازی

- `js/config.js`: ایمیل، Telegram، Endpoint فرم و مختصات دقیق.
- `index.html`: متن‌های معرفی، Certificates، Achievements، Testimonials و پروژه‌ها.
- `assets/images`: عکس‌های Hero و معرفی پایانی.
- `assets/video`: فایل‌های Demo ویدئویی.
- `assets/audio`: موسیقی پس‌زمینه.
- `css/styles.css`: رنگ‌ها و ظاهر در متغیرهای `:root`.
- `js/app.js`: منطق زبان، Theme، Slider، Voice، فرم، Search و Location.
