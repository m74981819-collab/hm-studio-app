@echo off
set DIR=%~dp0
if exist "%DIR%gradle\wrapper\gradle-wrapper.jar" (
  java -classpath "%DIR%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
  exit /b %ERRORLEVEL%
)
echo Gradle wrapper JAR is missing.
echo Open android-app in Android Studio and sync Gradle, or install Gradle 8.11.1.
exit /b 2
